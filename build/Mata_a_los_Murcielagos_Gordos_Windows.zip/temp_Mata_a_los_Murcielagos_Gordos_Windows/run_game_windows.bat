@echo off
echo 🎮 Iniciando "Mata a los Murcielagos Gordos"...
echo.

REM Buscar Godot en ubicaciones comunes de Windows
set GODOT_PATH=""

REM Verificar ubicaciones comunes de instalación
if exist "C:\Program Files\Godot\godot.exe" (
    set GODOT_PATH="C:\Program Files\Godot\godot.exe"
) else if exist "C:\Program Files (x86)\Godot\godot.exe" (
    set GODOT_PATH="C:\Program Files (x86)\Godot\godot.exe"
) else if exist "%USERPROFILE%\Desktop\Godot\godot.exe" (
    set GODOT_PATH="%USERPROFILE%\Desktop\Godot\godot.exe"
) else if exist "%USERPROFILE%\Downloads\Godot\godot.exe" (
    set GODOT_PATH="%USERPROFILE%\Downloads\Godot\godot.exe"
) else if exist "godot.exe" (
    set GODOT_PATH="godot.exe"
)

REM Si no se encuentra Godot, mostrar instrucciones
if %GODOT_PATH%=="" (
    echo ❌ No se encontró Godot Engine en el sistema.
    echo.
    echo 📥 Para ejecutar este juego necesitas descargar Godot Engine:
    echo    1. Ve a: https://godotengine.org/download
    echo    2. Descarga Godot 4.4.1 o superior
    echo    3. Extrae el archivo godot.exe en esta carpeta
    echo    4. Ejecuta este script nuevamente
    echo.
    echo 💡 Alternativamente, puedes:
    echo    - Instalar Godot en C:\Program Files\Godot\
    echo    - O colocar godot.exe en esta misma carpeta
    echo.
    pause
    exit /b 1
)

REM Ejecutar el juego
echo ✅ Godot encontrado en: %GODOT_PATH%
echo 🚀 Iniciando juego...
echo.

%GODOT_PATH% project.godot

echo.
echo 🎯 Juego terminado. ¡Gracias por jugar!
pause
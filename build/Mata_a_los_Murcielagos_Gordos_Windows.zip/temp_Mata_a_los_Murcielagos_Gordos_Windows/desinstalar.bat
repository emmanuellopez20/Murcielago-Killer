@echo off
echo ¿Estás seguro de que quieres desinstalar "Mata a los Murcielagos Gordos"? (S/N)
set /p confirm="> "
if /i "%confirm%"=="S" (
    echo Eliminando archivos del juego...
    cd ..
    rmdir /s /q "%~dp0"
    echo ¡Juego desinstalado! Gracias por jugar.
    pause
)

@echo off
title Configurador - Mata a los Murcielagos Gordos
color 0A

echo ===============================================
echo    🎮 MATA A LOS MURCIELAGOS GORDOS 🎮
echo ===============================================
echo.
echo Este script te ayudará a configurar el juego
echo en tu sistema Windows.
echo.

REM Verificar si Godot ya está instalado
echo 🔍 Verificando instalación de Godot...

set GODOT_FOUND=0
if exist "C:\Program Files\Godot\godot.exe" set GODOT_FOUND=1
if exist "C:\Program Files (x86)\Godot\godot.exe" set GODOT_FOUND=1
if exist "%USERPROFILE%\Desktop\Godot\godot.exe" set GODOT_FOUND=1
if exist "godot.exe" set GODOT_FOUND=1

if %GODOT_FOUND%==1 (
    echo ✅ Godot Engine encontrado en el sistema
    echo.
    echo ¿Quieres ejecutar el juego ahora? (S/N)
    set /p choice="> "
    if /i "%choice%"=="S" (
        call run_game_windows.bat
        exit /b 0
    )
) else (
    echo ❌ Godot Engine no encontrado
    echo.
    echo 📥 OPCIONES DE INSTALACIÓN:
    echo.
    echo 1. Descargar Godot automáticamente (recomendado)
    echo 2. Instrucciones para descarga manual
    echo 3. Usar Godot portable (colocar godot.exe aquí)
    echo 4. Salir
    echo.
    set /p option="Selecciona una opción (1-4): "
    
    if "%option%"=="1" goto download_godot
    if "%option%"=="2" goto manual_instructions
    if "%option%"=="3" goto portable_instructions
    if "%option%"=="4" exit /b 0
)

:download_godot
echo.
echo 🌐 Abriendo página de descarga de Godot...
start https://godotengine.org/download/windows/
echo.
echo 📋 INSTRUCCIONES:
echo 1. Descarga "Godot Engine - Standard version"
echo 2. Extrae el archivo ZIP
echo 3. Copia godot.exe a esta carpeta
echo 4. Ejecuta run_game_windows.bat
echo.
goto end

:manual_instructions
echo.
echo 📋 INSTRUCCIONES MANUALES:
echo.
echo 1. Ve a: https://godotengine.org/download/windows/
echo 2. Descarga "Godot Engine - Standard version" (4.4.1+)
echo 3. Extrae el archivo ZIP descargado
echo 4. Instala Godot en C:\Program Files\Godot\
echo    O copia godot.exe a esta carpeta del juego
echo 5. Ejecuta run_game_windows.bat para jugar
echo.
goto end

:portable_instructions
echo.
echo 📁 CONFIGURACIÓN PORTABLE:
echo.
echo 1. Descarga Godot desde: https://godotengine.org/download/windows/
echo 2. Extrae el ZIP y copia godot.exe
echo 3. Pega godot.exe en esta carpeta (junto a este script)
echo 4. Ejecuta run_game_windows.bat
echo.
echo 💡 Esta es la opción más simple - no requiere instalación
echo.

:end
echo.
echo ===============================================
echo 🎮 Configuración completada
echo ===============================================
echo.
echo Para jugar en el futuro, simplemente ejecuta:
echo run_game_windows.bat
echo.
pause